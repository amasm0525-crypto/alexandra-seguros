import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Services from './components/Services';
import About from './components/About';
import Process from './components/Process';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import ContactForm from './components/ContactForm';
import WhatsAppButton from './components/WhatsAppButton';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="relative min-h-screen flex flex-col bg-white-cream antialiased">
      {/* Structural Header (Sticky Navbar) */}
      <header>
        <Navbar />
      </header>

      {/* Main Sections Body */}
      <main className="flex-grow">
        
        {/* 1. Hero Presentational Grid */}
        <section id="hero">
          <Hero />
        </section>

        {/* 2. Pain Points / The Problem Section */}
        <section id="problemas">
          <PainPoints />
        </section>

        {/* 3. Services Offered Section */}
        <section id="servicios">
          <Services />
        </section>

        {/* 4. Biography / History Section */}
        <section id="sobre-mi">
          <About />
        </section>

        {/* 5. Process Sequence Section */}
        <section id="proceso">
          <Process />
        </section>

        {/* 6. Success Stories / Testimonials Section */}
        <section id="testimonios">
          <Testimonials />
        </section>

        {/* 7. Accordion FAQ Section */}
        <section id="faq">
          <FAQ />
        </section>

        {/* 8. Interactive Validation Contact Form Form */}
        <section id="contacto">
          <ContactForm />
        </section>

      </main>

      {/* Global Floating Action Element (Siempre visible) */}
      <WhatsAppButton />

      {/* Corporate footer details */}
      <Footer />
    </div>
  );
}
