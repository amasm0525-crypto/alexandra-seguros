import React from 'react';
import { motion } from 'motion/react';
import { PhoneCall, CalendarDays, KeyRound, MessageCircleCode } from 'lucide-react';

export default function Process() {
  const steps = [
    {
      number: "01",
      title: "Conversamos",
      description: "Cuéntame tu situación en una llamada o WhatsApp, sin costo.",
      icon: <PhoneCall className="text-white-cream" size={20} />,
      detail: "Evaluación inicial de 10 minutos."
    },
    {
      number: "02",
      title: "Diseño tu plan",
      description: "Analizo tu caso y te presento opciones que se ajustan a tu presupuesto.",
      icon: <CalendarDays className="text-white-cream" size={20} />,
      detail: "Opciones claras, sin compromisos."
    },
    {
      number: "03",
      title: "Te protejo",
      description: "Activamos tu póliza y tu familia queda protegida desde el primer día.",
      icon: <KeyRound className="text-white-cream" size={20} />,
      detail: "Paz mental inmediata y activa."
    }
  ];

  return (
    <section 
      id="proceso" 
      className="py-24 bg-gradient-to-b from-[#EBE2D3] to-[#F8F5F0] text-dark-text relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-20">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee mb-3 font-mono"
          >
            Paso a Paso
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810]"
          >
            Es más fácil de lo que crees
          </motion.h2>
          <div className="w-16 h-1 bg-gold-soft mx-auto mt-4 rounded-full" />
        </div>

        {/* Horizontal/Vertical Steps Layout */}
        <div className="relative">
          
          {/* Central Connecting Line (only on desktop md+) */}
          <div className="hidden md:block absolute top-[52px] left-[15%] right-[15%] h-0.5 bg-gradient-to-r from-brown-coffee/10 via-gold-soft/60 to-brown-coffee/10 z-0" />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative z-10">
            {steps.map((step, idx) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6, delay: idx * 0.18 }}
                className="text-center group flex flex-col items-center"
              >
                
                {/* Number / Bubble */}
                <div className="relative mb-6">
                  {/* Decorative Outer Ring on Hover */}
                  <div className="absolute -inset-2 bg-[#C8A96B]/10 rounded-full scale-0 group-hover:scale-100 transition-transform duration-300 pointer-events-none" />
                  
                  <div className="w-16 h-16 rounded-full bg-white border-2 border-gold-soft flex items-center justify-center shadow-lg relative z-10">
                    <span className="font-serif text-2xl font-bold text-brown-coffee">
                      {step.number}
                    </span>
                  </div>

                  {/* Micro Floating Icon */}
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#6F4E37] flex items-center justify-center shadow z-20">
                    {step.icon}
                  </div>
                </div>

                {/* Step Text Content */}
                <h3 className="font-serif text-lg sm:text-xl font-bold text-dark-text mb-3">
                  {step.title}
                </h3>
                
                <p className="text-sm text-dark-text/80 leading-relaxed max-w-sm font-normal px-2">
                  {step.description}
                </p>

                {/* Step Meta Note */}
                <span className="mt-4 inline-block text-[10px] uppercase font-bold tracking-widest font-mono text-brown-coffee/70 bg-brown-coffee/5 px-2.5 py-1 rounded-full">
                  {step.detail}
                </span>

              </motion.div>
            ))}
          </div>

        </div>

        {/* Big Bottom Action Link as requested */}
        <div className="mt-16 text-center select-none">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4 }}
          >
            <a
              id="process-cta-whatsapp"
              href="https://wa.me/18133047291"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold py-4 px-10 rounded-xl shadow-xl hover:shadow-2xl transition-all hover:scale-[1.02] active:scale-98"
            >
              <MessageCircleCode size={20} className="animate-pulse" />
              Empezar ahora
            </a>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
