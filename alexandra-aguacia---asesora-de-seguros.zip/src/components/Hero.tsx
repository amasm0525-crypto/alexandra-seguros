import React from 'react';
import { motion } from 'motion/react';
import { Shield, Sparkles, Navigation, Users, CheckCircle, Smartphone } from 'lucide-react';

export default function Hero() {
  const handleScrollToServices = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const servicesSection = document.querySelector('#servicios');
    if (servicesSection) {
      const offset = 80;
      const targetPosition = servicesSection.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section 
      id="hero" 
      className="relative min-h-screen pt-28 pb-16 flex items-center overflow-hidden bg-gradient-to-b from-[#F8F5F0] via-[#F3EDDF] to-[#EBE2D3]"
    >
      {/* Decorative Warm Radial Orbs for Luxury/Professional Glow */}
      <div className="absolute top-1/4 left-0 w-72 h-72 bg-[#C8A96B]/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-96 h-96 bg-[#6F4E37]/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Hero Text Content (7 columns on large screen) */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold-soft/10 border border-gold-soft/30 text-brown-coffee text-xs font-semibold tracking-wider uppercase"
            >
              <Sparkles size={14} className="text-gold-soft animate-pulse" />
              Asesoría de Seguros 100% en Español
            </motion.div>

            <motion.h1
              id="hero-title"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-dark-text tracking-tight leading-tight select-none"
            >
              Protege lo que más <span className="text-brown-coffee italic text-shadow-sm">amas</span> con el seguro correcto
            </motion.h1>

            <motion.p
              id="hero-subheadline"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-base sm:text-lg text-dark-text/80 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed"
            >
              Soy <strong>Alexandra Aguacia</strong>, asesora certificada de seguros. Te ayudo a encontrar la protección perfecta para tu familia: sin complicaciones, libre de presiones y en tu propio idioma.
            </motion.p>

            {/* CTA Action Buttons */}
            <motion.div
              id="hero-ctas"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4"
            >
              <a
                id="hero-cta-whatsapp"
                href="https://wa.me/18133047291"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#C8A96B] hover:bg-[#B69658] text-[#2C1810] font-bold text-base px-8 py-4 rounded-xl shadow-lg hover:shadow-xl hover:translate-y-[-1px] active:translate-y-[0px] active:scale-98 transition-all"
              >
                <Smartphone size={18} className="animate-bounce" />
                Habla con Alexandra
              </a>
              <button
                id="hero-cta-services"
                onClick={handleScrollToServices}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 border-2 border-brown-coffee/40 hover:border-brown-coffee hover:bg-brown-coffee/5 text-brown-coffee font-semibold text-base px-8 py-3.8 rounded-xl transition-all cursor-pointer"
              >
                <Navigation size={16} />
                Ver mis servicios
              </button>
            </motion.div>

            {/* Trust Indicators / Badges - Structured precisely as requested */}
            <motion.div
              id="hero-trust-badges"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="pt-6 border-t border-beige-warm/40 flex flex-wrap items-center justify-center lg:justify-start gap-4 sm:gap-6 text-sm text-dark-text/90"
            >
              <div className="flex items-center gap-1.5 focus:outline-none">
                <span className="text-amber-500 font-bold">⭐⭐⭐⭐⭐</span>
                <span className="font-semibold block shrink-0">+200 familias protegidas</span>
              </div>
              <div className="hidden sm:block text-beige-warm/90">|</div>
              <div className="flex items-center gap-2">
                <span className="text-lg leading-none shrink-0" aria-label="Bandera estadounidense">🇺🇸</span>
                <span className="font-semibold text-brown-coffee">Licensed in Florida</span>
              </div>
              <div className="hidden sm:block text-beige-warm/90">|</div>
              <div className="flex items-center gap-2">
                <span className="text-lg leading-none shrink-0" aria-label="Voces de chat">🗣️</span>
                <span className="font-semibold bg-[#6F4E37]/10 px-2 py-0.5 rounded text-brown-coffee antialiased">Atención en Español</span>
              </div>
            </motion.div>
          </div>

          {/* Hero Side Graphic Representation (5 columns on large screen) */}
          <div className="lg:col-span-5 flex justify-center items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative w-full max-w-[380px] sm:max-w-[420px] aspect-square rounded-3xl bg-[#F8F5F0] border-2 border-[#D8C3A5] shadow-2xl p-6 sm:p-8 overflow-hidden flex flex-col justify-between"
            >
              {/* Graphic background elegant circles */}
              <div className="absolute -top-12 -right-12 w-44 h-44 rounded-full bg-[#C8A96B]/10 border border-[#C8A96B]/20" />
              <div className="absolute -bottom-16 -left-16 w-52 h-52 rounded-full bg-[#6F4E37]/10" />

              {/* Header Badge */}
              <div className="flex justify-between items-center relative z-10">
                <div className="h-8 w-8 rounded-lg bg-[#6F4E37] flex items-center justify-center text-[#F8F5F0]">
                  <Shield size={18} />
                </div>
                <div className="bg-[#C8A96B]/20 text-[#6F4E37] rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wider border border-[#C8A96B]/45">
                  Seguridad Familiar
                </div>
              </div>

              {/* Inside abstract family representation (elegant SVG/HTML composition) */}
              <div className="my-6 relative z-10 flex flex-col items-center py-6">
                {/* Abstract human layout representing protection */}
                <div className="relative flex justify-center items-end h-28 w-44">
                  {/* father figure */}
                  <div className="w-10 h-20 bg-[#6F4E37] rounded-t-full mx-1 shadow-sm relative transition-all hover:scale-105" />
                  {/* mother figure */}
                  <div className="w-10 h-18 bg-[#C8A96B] rounded-t-full mx-1 shadow-sm relative transition-all hover:scale-105" />
                  {/* child figure */}
                  <div className="w-7 h-12 bg-[#2C1810]/70 rounded-t-full mx-1 shadow-sm relative transition-all hover:scale-105" />
                  
                  {/* Protecting glass canopy */}
                  <div className="absolute top-0 left-0 right-0 h-28 border-t-4 border-l-4 border-r-4 border-dashed border-[#C8A96B]/50 rounded-t-full pointer-events-none" />
                </div>
                
                <p className="font-serif text-lg font-bold text-dark-text mt-8 text-center max-w-[240px]">
                  "Tu familia unida, tu legado protegido"
                </p>
                <p className="text-xs text-dark-text/70 mt-1 uppercase tracking-widest font-mono">
                  Alexandra Aguacia Cert.
                </p>
              </div>

              {/* Small interactive floating indicators */}
              <div className="flex justify-between items-center border-t border-[#D8C3A5]/40 pt-4 relative z-10">
                <div className="flex items-center gap-1">
                  <CheckCircle size={14} className="text-[#C8A96B]" />
                  <span className="text-[11px] text-dark-text/80 font-bold">100% Personalizado</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users size={14} className="text-[#6F4E37]" />
                  <span className="text-[11px] text-dark-text/80 font-bold">Sin Exclusiones</span>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
