import React from 'react';

interface CompanyLogoProps {
  variant?: 'icon' | 'full' | 'vertical';
  className?: string;
  light?: boolean; // If true, colors are suited for dark backgrounds (white/cream/gold). If false, suited for light backgrounds (coffee/dark text).
}

export default function CompanyLogo({ variant = 'full', className = '', light = false }: CompanyLogoProps) {
  // Brand Colors from guidelines
  const primaryColor = light ? '#F8F5F0' : '#6F4E37'; // White Cream vs Brown Coffee
  const accentColor = '#C8A96B'; // Soft Gold
  const textColor = light ? '#F8F5F0' : '#2C1810'; // White Cream vs Dark Text

  // Inline SVG for the interlocking "AAA" Monogram
  // Designed to match the elegant serif letters with sweeping legs
  const renderMonogram = (sizeClass: string) => (
    <svg
      viewBox="0 0 320 220"
      className={sizeClass}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Monograma Alexandra Aguacia"
    >
      <g>
        {/* Underlay shadow/glow for soft effect */}
        <path
          d="M60 180 C110 180, 140 200, 190 205 M120 180 C170 180, 200 200, 250 205 M180 185 C230 185, 260 200, 310 205"
          stroke={accentColor}
          strokeWidth="3"
          strokeLinecap="round"
          opacity="0.3"
        />

        {/* --- FIRST 'A' (Back) --- */}
        <g stroke={primaryColor} strokeWidth="1.5" fill="none">
          {/* Main Diagonal Thin Stem (Left) */}
          <path
            d="M 125 40 L 65 178"
            stroke={primaryColor}
            strokeWidth="3"
            strokeLinecap="round"
          />
          {/* Main Thick Stem (Right) with swoop */}
          <path
            d="M 125 40 L 165 168 C 175 190, 195 200, 220 200"
            stroke={primaryColor}
            strokeWidth="9"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Crossbar */}
          <path d="M 85 130 H 155" stroke={primaryColor} strokeWidth="3" />
          {/* Serif Foot Left */}
          <path d="M 55 178 H 75" stroke={primaryColor} strokeWidth="4" strokeLinecap="round" />
        </g>

        {/* --- SECOND 'A' (Middle) --- */}
        <g stroke={primaryColor} strokeWidth="1.5" fill="none">
          {/* Main Diagonal Thin Stem (Left) */}
          <path
            d="M 180 40 L 120 178"
            stroke={primaryColor}
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {/* Main Thick Stem (Right) with swoop */}
          <path
            d="M 180 40 L 220 168 C 230 190, 250 200, 275 200"
            stroke={primaryColor}
            strokeWidth="9.5"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {/* Crossbar */}
          <path d="M 140 130 H 210" stroke={primaryColor} strokeWidth="3" />
          {/* Serif Foot Left */}
          <path d="M 110 178 H 130" stroke={primaryColor} strokeWidth="4" strokeLinecap="round" />
        </g>

        {/* --- THIRD 'A' (Front) --- */}
        <g stroke={primaryColor} strokeWidth="1.5" fill="none">
          {/* Main Diagonal Thin Stem (Left) */}
          <path
            d="M 235 40 L 175 178"
            stroke={primaryColor}
            strokeWidth="4"
            strokeLinecap="round"
          />
          {/* Main Thick Stem (Right) with swoop */}
          <path
            d="M 235 40 L 275 168 C 285 190, 305 200, 330 200"
            stroke={primaryColor}
            strokeWidth="10"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {/* Crossbar */}
          <path d="M 195 130 H 265" stroke={primaryColor} strokeWidth="3" />
          {/* Serif Foot Left */}
          <path d="M 165 178 H 185" stroke={primaryColor} strokeWidth="4" strokeLinecap="round" />
        </g>

        {/* Subtle Gold accent line cutting through the overlapping crossbars */}
        <path
          d="M 90 128 L 260 128"
          stroke={accentColor}
          strokeWidth="1.5"
          strokeLinecap="round"
          opacity="0.8"
        />
      </g>
    </svg>
  );

  if (variant === 'icon') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        {renderMonogram("w-full h-full")}
      </div>
    );
  }

  if (variant === 'vertical') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`}>
        {renderMonogram("w-32 h-auto mb-2")}
        <h1 className="font-serif tracking-[0.14em] uppercase font-bold text-lg leading-tight" style={{ color: textColor }}>
          Alexandra
        </h1>
        <h2 className="font-serif tracking-[0.14em] uppercase font-bold text-lg leading-tight" style={{ color: textColor }}>
          Aguacia
        </h2>
        <div className="w-8 h-[1px] my-2" style={{ backgroundColor: accentColor }} />
        <p className="text-[9px] uppercase tracking-[0.2em] font-medium font-sans" style={{ color: accentColor }}>
          Servicios Profesionales
        </p>
      </div>
    );
  }

  // Default 'full' horizontal/stacked brand logo representation
  return (
    <div className={`flex items-center gap-3.5 transition-all ${className}`}>
      {/* Visual icon */}
      <div className="w-12 h-10 flex-shrink-0">
        {renderMonogram("w-full h-full")}
      </div>
      
      {/* Text group */}
      <div className="flex flex-col">
        <div className="font-serif font-extrabold uppercase tracking-[0.08em] text-sm leading-none" style={{ color: textColor }}>
          Alexandra Aguacia
        </div>
        <div className="text-[8px] uppercase tracking-[0.15em] font-sans font-bold mt-1" style={{ color: accentColor }}>
          Servicios Profesionales
        </div>
      </div>
    </div>
  );
}
