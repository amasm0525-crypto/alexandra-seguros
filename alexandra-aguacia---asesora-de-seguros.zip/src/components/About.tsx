import React from 'react';
import { motion } from 'motion/react';
import { UserCheck, Award, ThumbsUp, ShieldCheck } from 'lucide-react';

const alexandraPortrait = "https://lh3.googleusercontent.com/d/1IOOGvVJVhpFxyH3c9ONECM8KndGGce1c";

export default function About() {
  const badges = [
    { text: "✓ Licenciada en Florida", desc: "Autorización estatal para asesorar pólizas", icon: <ShieldCheck size={16} className="text-gold-soft" /> },
    { text: "✓ +5 años de experiencia", desc: "Guiando a las familias en cada paso", icon: <Award size={16} className="text-gold-soft" /> },
    { text: "✓ Atención personalizada", desc: "Soluciones a la medida de tu presupuesto", icon: <ThumbsUp size={16} className="text-gold-soft" /> }
  ];

  return (
    <section 
      id="sobre-mi" 
      className="py-24 bg-white-cream text-dark-text relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Avatar / Portrait placeholder (5 columns on large screen) - Styled elegantly as requested */}
          <div className="lg:col-span-5 flex justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative w-full max-w-[340px] aspect-[4/5] rounded-2xl bg-gradient-to-tr from-brown-coffee via-[#8E6D55] to-gold-soft p-1.5 shadow-2xl group"
            >
              <div className="w-full h-full bg-[#fcf9f5] rounded-xl overflow-hidden relative flex flex-col justify-end p-6 select-none border border-beige-warm/20">
                {/* Abstract geometric shapes inside represent a silhouette */}
                <div className="absolute top-0 right-0 left-0 bottom-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent z-10" />
                
                {/* Portrait Image of Alexandra Aguacia */}
                <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-44 h-44 rounded-full bg-beige-warm flex items-center justify-center border-4 border-white-cream overflow-hidden shadow-lg">
                  <img
                    src={alexandraPortrait}
                    alt="Alexandra Aguacia"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center scale-105"
                  />
                </div>

                {/* Micro detail badge for portrait */}
                <div className="absolute top-4 right-4 z-20 bg-[#6F4E37]/90 text-white-cream text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider border border-gold-soft/40 shadow">
                  Asesora Certificada
                </div>

                {/* Copy inside placeholder representing Name/Sign */}
                <div className="relative z-20 text-center text-white-cream">
                  <h4 className="font-serif text-xl font-bold">Alexandra Aguacia</h4>
                  <p className="text-xs text-gold-soft font-semibold tracking-wider uppercase mt-1">License #W836254 (FL)</p>
                  <p className="text-[10px] text-white-cream/70 mt-2 italic">"Apasionada por la protección familiar"</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Biography Content (7 columns on large screen) */}
          <div className="lg:col-span-7 space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <span className="text-xs uppercase tracking-widest font-bold text-brown-coffee font-mono">
                  Asesoría humana y transparente
                </span>
                <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810]">
                  Hola, soy Alexandra Aguacia
                </h2>
                <div className="w-16 h-1 bg-gold-soft rounded-full" />
              </div>

              <div className="space-y-4 text-sm sm:text-base text-dark-text/85 font-normal leading-relaxed">
                <p>
                  Soy una asesora certificada de seguros apasionada por ayudar a familias hispanas en los Estados Unidos a proteger su futuro y construir un legado financiero estable.
                </p>
                <p>
                  Comprendo profundamente tus inquietudes financieras y el anhelo de ver progresar a los tuyos porque comparto tu cultura, tu camino y hablo tu mismo idioma. En la vida existen variables que no podemos controlar, pero la seguridad habitacional y económica de tus hijos es algo que sí podemos planificar hoy.
                </p>
                <p className="font-semibold text-brown-coffee">
                  Mi misión absoluta es que tomes la mejor decisión posible para tu hogar, entregándote información sumamente transparente, sin presiones y totalmente en español.
                </p>
              </div>

              {/* 3 Credibility badges stacked with icons */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-beige-warm/30">
                {badges.map((badge, index) => (
                  <div key={index} className="p-3 bg-white border border-beige-warm/30 rounded-xl flex items-start gap-2.5 shadow-sm hover:border-[#C8A96B]/50 transition-colors">
                    <div className="p-1 rounded-full bg-gold-soft/10 mt-0.5">
                      {badge.icon}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-dark-text leading-tight">{badge.text}</h4>
                      <p className="text-[9px] text-[#2C1810]/70 mt-0.5 leading-snug">{badge.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
}
