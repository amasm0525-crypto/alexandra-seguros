import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle } from 'lucide-react';

export default function WhatsAppButton() {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center">
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, x: 10, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 10, scale: 0.95 }}
            className="mr-3 bg-dark-text text-white-cream text-xs font-semibold py-2 px-3 rounded-lg shadow-lg whitespace-nowrap hidden sm:block pointer-events-none"
            id="wa-tooltip"
          >
            ¡Escríbeme ahora!
          </motion.div>
        )}
      </AnimatePresence>

      <motion.a
        id="wa-floating-btn"
        href="https://wa.me/18133047291"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Contactar a Alexandra por WhatsApp"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        className="relative flex items-center justify-center w-14 h-14 bg-[#25D366] text-white rounded-full shadow-2xl hover:bg-[#20ba59] active:scale-95 transition-transform"
        animate={{
          boxShadow: [
            "0 0 0 0px rgba(37, 211, 102, 0.4)",
            "0 0 0 12px rgba(37, 211, 102, 0)",
            "0 0 0 0px rgba(37, 211, 102, 0.4)"
          ]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      >
        <MessageCircle size={28} className="fill-current text-white" />
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-[9px] text-white font-bold items-center justify-center">1</span>
        </span>
      </motion.a>
    </div>
  );
}
