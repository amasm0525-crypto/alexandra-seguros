import React from 'react';
import { Shield, Sparkles, Phone, Mail, Globe, ArrowUp } from 'lucide-react';
import CompanyLogo from './CompanyLogo';

export default function Footer() {
  const handleScrollToTop = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80;
      const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer 
      id="main-footer" 
      className="bg-[#2C1810] text-[#F8F5F0] pt-16 pb-8 border-t-2 border-gold-soft/30 select-none"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#F8F5F0]/10">
          
          {/* Brand/Column 1 (5 columns on desktop) */}
          <div className="md:col-span-12 lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <a 
                href="#hero" 
                onClick={(e) => handleLinkClick(e, '#hero')}
                className="focus:outline-none focus:ring-2 focus:ring-gold-soft/50 rounded-lg p-1 block transition-transform hover:scale-102"
                aria-label="Ir al inicio"
              >
                <CompanyLogo light={true} />
              </a>
            </div>
            
            <p className="text-sm text-white-cream/70 max-w-sm leading-relaxed font-normal">
              <strong>Asesora Certificada de Seguros.</strong> Comprometida con brindar protección inteligente, transparente y en español para edificar el legado de las familias hispanas en los Estados Unidos.
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-white-cream/10 border border-white-cream/10 rounded-full text-[10px] uppercase font-bold tracking-wider text-gold-soft">
                <Shield size={10} />
                Licensed in Florida
              </span>
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-white-cream/10 border border-white-cream/10 rounded-full text-[10px] uppercase font-bold tracking-wider text-gold-soft">
                <Sparkles size={10} />
                Atención en Español
              </span>
            </div>
          </div>

          {/* Quick Links Column (3 columns on desktop) */}
          <div className="md:col-span-6 lg:col-span-3 space-y-4">
            <h4 className="text-xs uppercase tracking-widest font-bold text-gold-soft font-mono">
              Enlaces Rápidos
            </h4>
            <ul className="space-y-2 text-sm text-white-cream/80 font-medium">
              <li>
                <a 
                  href="#servicios" 
                  onClick={(e) => handleLinkClick(e, '#servicios')}
                  className="hover:text-gold-soft transition-colors"
                >
                  Servicios
                </a>
              </li>
              <li>
                <a 
                  href="#sobre-mi" 
                  onClick={(e) => handleLinkClick(e, '#sobre-mi')}
                  className="hover:text-gold-soft transition-colors"
                >
                  Sobre Mí
                </a>
              </li>
              <li>
                <a 
                  href="#faq" 
                  onClick={(e) => handleLinkClick(e, '#faq')}
                  className="hover:text-gold-soft transition-colors"
                >
                  FAQ
                </a>
              </li>
              <li>
                <a 
                  href="#contacto" 
                  onClick={(e) => handleLinkClick(e, '#contacto')}
                  className="hover:text-gold-soft transition-colors"
                >
                  Contacto
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Details Column (4 columns on desktop) */}
          <div className="md:col-span-6 lg:col-span-4 space-y-4">
            <h4 className="text-xs uppercase tracking-widest font-bold text-gold-soft font-mono">
              Información de Contacto
            </h4>
            <ul className="space-y-3.5 text-sm text-white-cream/80">
              <li className="flex items-start gap-2.5">
                <Phone size={16} className="text-gold-soft mt-0.5 shrink-0" />
                <span className="font-semibold">+1 (813) 304-7291</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail size={16} className="text-gold-soft mt-0.5 shrink-0" />
                <span className="font-semibold break-all">info@alexandraaguacia.com</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Globe size={16} className="text-gold-soft mt-0.5 shrink-0" />
                <span className="font-semibold">www.alexandraaguacia.com</span>
              </li>
            </ul>

            {/* Social network shortcuts as requested */}
            <div className="pt-2 flex items-center gap-3">
              <span className="text-[11px] text-white-cream/50 uppercase font-bold tracking-widest font-mono">Conéctate:</span>
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                aria-label="Facebook (Placeholder)"
                className="w-8 h-8 rounded-full bg-white-cream/10 flex items-center justify-center text-white-cream hover:bg-gold-soft hover:text-[#2C1810]"
              >
                <span className="font-bold text-xs uppercase text-[10px]">FB</span>
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                aria-label="Instagram (Placeholder)"
                className="w-8 h-8 rounded-full bg-white-cream/10 flex items-center justify-center text-white-cream hover:bg-gold-soft hover:text-[#2C1810]"
              >
                <span className="font-bold text-xs uppercase text-[10px]">IG</span>
              </a>
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                aria-label="LinkedIn (Placeholder)"
                className="w-8 h-8 rounded-full bg-white-cream/10 flex items-center justify-center text-white-cream hover:bg-gold-soft hover:text-[#2C1810]"
              >
                <span className="font-bold text-xs uppercase text-[10px]">LN</span>
              </a>
            </div>
          </div>

        </div>

        {/* Legal credentials and Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-white-cream/60">
          <div className="text-center sm:text-left space-y-1">
            <p className="font-medium text-white-cream/80">© 2025 Alexandra Aguacia. Todos los derechos reservados.</p>
            <p className="text-[10px] text-white-cream/50 max-w-xl font-normal leading-normal">
              Alexandra Aguacia es una asesora autorizada por el departamento de servicios financieros. El contenido de este sitio web es netamente informativo y no constituye una cotización ni aprobación de póliza formal. Las aseguradoras imponen directrices y requerimientos de elegibilidad específicos.
            </p>
          </div>

          <button
            id="footer-back-to-top"
            onClick={handleScrollToTop}
            className="p-3 rounded-xl bg-white-cream/10 hover:bg-gold-soft hover:text-[#2C1810] text-white-cream transition-all group shrink-0 focus:outline-none"
            aria-label="Volver arriba"
          >
            <ArrowUp size={16} className="group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

      </div>
    </footer>
  );
}
