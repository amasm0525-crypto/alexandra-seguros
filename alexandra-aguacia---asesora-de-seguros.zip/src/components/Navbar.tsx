import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, MessageSquareCode } from 'lucide-react';
import CompanyLogo from './CompanyLogo';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Servicios', href: '#servicios' },
    { name: 'Sobre Mí', href: '#sobre-mi' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contacto', href: '#contacto' }
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80; // height of the navbar
      const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <nav
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled 
          ? 'bg-white-cream/95 backdrop-blur-md shadow-md py-3 border-b border-beige-warm/30' 
          : 'bg-white-cream py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo / Brand Name */}
          <a 
            href="#hero" 
            onClick={(e) => handleLinkClick(e, '#hero')}
            className="focus:outline-none focus:ring-2 focus:ring-gold-soft/50 rounded-lg p-1 block transition-transform hover:scale-102"
            aria-label="Ir al inicio"
          >
            <CompanyLogo />
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={(e) => handleLinkClick(e, item.href)}
                className="text-dark-text/80 hover:text-brown-coffee font-medium text-sm transition-colors relative group py-2"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold-soft transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* Desktop Call To Action Button */}
          <div className="hidden md:block">
            <a
              id="nav-cta-whatsapp"
              href="https://wa.me/18133047291"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba59] text-white font-semibold text-sm px-5 py-2.5 rounded-full shadow-sm hover:shadow active:scale-95 transition-all duration-150 border border-emerald-600/10"
            >
              <MessageSquareCode size={16} />
              Contáctame por WhatsApp
            </a>
          </div>

          {/* Mobile Hamburger toggle */}
          <div className="md:hidden">
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-brown-coffee hover:text-dark-text bg-beige-warm/15 hover:bg-beige-warm/25 rounded-lg focus:outline-none transition-colors"
              aria-expanded={isOpen}
              aria-label="Abrir menú de navegación"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-nav-panel"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="md:hidden bg-white-cream border-t border-beige-warm/30 overflow-hidden"
          >
            <div className="px-4 pt-4 pb-6 space-y-3 shadow-inner">
              {menuItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={(e) => handleLinkClick(e, item.href)}
                  className="block px-4 py-3 text-base font-semibold text-dark-text hover:text-brown-coffee bg-beige-warm/10 hover:bg-beige-warm/25 rounded-xl transition-all"
                >
                  {item.name}
                </a>
              ))}
              <div className="pt-2">
                <a
                  id="mobile-nav-cta-whatsapp"
                  href="https://wa.me/18133047291"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full bg-[#25D366] hover:bg-[#20ba59] text-white text-center font-bold px-4 py-3.5 rounded-xl shadow-md transition-all active:scale-98"
                >
                  <MessageSquareCode size={20} />
                  Contáctame por WhatsApp
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
