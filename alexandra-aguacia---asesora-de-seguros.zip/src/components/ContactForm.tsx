import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Phone, Mail, MapPin, MessageSquareCode, Clock, ShieldCheck, ArrowUpRight, Lock } from 'lucide-react';

export default function ContactForm() {
  const [iframeLoading, setIframeLoading] = useState(true);

  return (
    <section 
      id="contacto" 
      className="py-24 bg-beige-warm text-[#2C1810]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee mb-3 font-mono"
          >
            Formulario de Asesoría
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810]"
          >
            Comienza tu Cotización
          </motion.h2>
          <p className="text-[#6F4E37] text-sm sm:text-base mt-2">
            Completa nuestro formulario oficial a continuación para evaluar tu caso y preparar una propuesta de cobertura personalizada.
          </p>
          <div className="w-16 h-1 bg-[#6F4E37] mx-auto mt-4 rounded-full" />
        </div>

        {/* 2-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start max-w-6xl mx-auto">
          
          {/* COLUMN 1: LeadConnector Embedded Form (7 columns on desktop) */}
          <div className="lg:col-span-7 bg-white-cream rounded-3xl p-4 sm:p-8 border-2 border-[#C8A96B] shadow-lg relative overflow-hidden">
            <div className="mb-6 flex items-center justify-between border-b border-brown-coffee/10 pb-4">
              <div>
                <h3 className="font-serif text-lg sm:text-xl font-bold text-dark-text">Registro Seguro</h3>
                <p className="text-xs text-[#6F4E37]">Tus datos están protegidos por cifrado de extremo a extremo</p>
              </div>
              <div className="bg-[#C8A96B]/10 p-2 rounded-full text-brown-coffee flex items-center gap-1">
                <Lock size={14} className="text-[#C8A96B]" />
                <span className="text-[10px] font-bold font-mono tracking-wider uppercase text-brown-coffee">Secure SSL</span>
              </div>
            </div>

            {/* Form Frame Container */}
            <div className="relative w-full min-h-[600px] sm:min-h-[660px] bg-white rounded-2xl overflow-hidden shadow-inner">
              
              {/* Shimmering Loading Skeleton */}
              {iframeLoading && (
                <div className="absolute inset-0 bg-white p-6 space-y-6 flex flex-col justify-start animate-pulse z-10">
                  <div className="h-4 bg-beige-warm/65 rounded w-1/3" />
                  <div className="space-y-2">
                    <div className="h-10 bg-beige-warm/40 rounded-xl w-full" />
                  </div>
                  <div className="h-4 bg-beige-warm/65 rounded w-1/4" />
                  <div className="space-y-2">
                    <div className="h-10 bg-beige-warm/40 rounded-xl w-full" />
                  </div>
                  <div className="h-4 bg-beige-warm/65 rounded w-2/5" />
                  <div className="space-y-2">
                    <div className="h-10 bg-beige-warm/40 rounded-xl w-full" />
                  </div>
                  <div className="space-y-2 pt-4">
                    <div className="h-12 bg-[#6F4E37]/15 rounded-xl w-full flex items-center justify-center">
                      <div className="w-16 h-3 bg-brown-coffee/20 rounded" />
                    </div>
                  </div>
                </div>
              )}

              {/* LeadConnector Embedded Form iframe */}
              <iframe
                src="https://api.leadconnectorhq.com/widget/form/tspq05IcXGGiqXLbxX6d"
                style={{ width: '100%', height: '100%', minHeight: '660px', border: 'none' }}
                id="inline-tspq05IcXGGiqXLbxX6d"
                data-layout="{'id':'INLINE'}"
                data-trigger-type="alwaysShow"
                data-form-name="Formulario Seguros"
                title="LeadConnector Contact Form"
                onLoad={() => setIframeLoading(false)}
                className="w-full h-full transition-opacity duration-500"
              />
            </div>
          </div>

          {/* COLUMN 2: Direct Support and trust info (5 columns on desktop) */}
          <div className="lg:col-span-5 space-y-8">
            
            {/* Lead Card summary info */}
            <div className="bg-white-cream rounded-3xl p-6 sm:p-8 border border-brown-coffee/15 shadow-sm space-y-6">
              <h3 className="font-serif text-xl font-bold text-dark-text border-b border-brown-coffee/10 pb-4">
                Asistencia y Contacto Continuo
              </h3>
              
              <p className="text-xs sm:text-sm text-[#2C1810]/85 leading-relaxed">
                Si prefieres saltarte el formulario, puedes escribirnos por WhatsApp, llamarnos por teléfono o enviarnos un correo oficial directamente:
              </p>

              {/* Channels list */}
              <div className="space-y-4 pt-2">
                {/* Channel 1: WhatsApp */}
                <a
                  href="https://wa.me/18133047291"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 p-3 bg-white hover:bg-emerald-50 rounded-2xl border border-brown-coffee/10 hover:border-emerald-200 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                    <MessageSquareCode size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[9px] font-bold tracking-widest text-emerald-700 uppercase">Respuesta Rápida</span>
                    <span className="block text-sm font-bold text-[#2C1810] group-hover:text-emerald-700 transition-colors">WhatsApp Directo</span>
                  </div>
                  <ArrowUpRight size={16} className="text-emerald-600/50 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>

                {/* Channel 2: Phone call */}
                <a
                  href="tel:+18133047291"
                  className="flex items-center gap-4 p-3 bg-white hover:bg-brown-coffee/5 rounded-2xl border border-brown-coffee/10 hover:border-brown-coffee/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-gold-soft/10 flex items-center justify-center text-brown-coffee shrink-0">
                    <Phone size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[9px] font-bold tracking-widest text-brown-coffee/70 uppercase">Llamar Ahora</span>
                    <span className="block text-sm font-bold text-[#2C1810] group-hover:text-brown-coffee transition-colors">+1 (813) 304-7291</span>
                  </div>
                  <ArrowUpRight size={16} className="text-[#C8A96B] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>

                {/* Channel 3: Email */}
                <a
                  href="mailto:alexandra.aguacia.seguros@gmail.com"
                  className="flex items-center gap-4 p-3 bg-white hover:bg-brown-coffee/5 rounded-2xl border border-brown-coffee/10 hover:border-brown-coffee/30 transition-all group"
                >
                  <div className="w-10 h-10 rounded-full bg-gold-soft/10 flex items-center justify-center text-brown-coffee shrink-0">
                    <Mail size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-[9px] font-bold tracking-widest text-brown-coffee/70 uppercase">Escribir Correo</span>
                    <span className="block text-sm font-bold text-[#2C1810] group-hover:text-brown-coffee transition-colors truncate">info@alexandraaguacia.com</span>
                  </div>
                  <ArrowUpRight size={16} className="text-[#C8A96B] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              </div>
            </div>

            {/* Quick trust metrics and licensing verification details */}
            <div className="bg-white-cream rounded-3xl p-6 sm:p-8 border border-brown-coffee/15 shadow-sm space-y-6">
              <h4 className="font-serif text-base font-bold text-[#2C1810] border-b border-brown-coffee/10 pb-3">
                Detalles Operativos
              </h4>

              <div className="space-y-4 text-xs sm:text-sm">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-gold-soft/10 flex items-center justify-center shrink-0 text-brown-coffee mt-0.5">
                    <Clock size={16} />
                  </div>
                  <div>
                    <p className="font-bold text-[10px] uppercase tracking-wider text-brown-coffee/80">Horario Hábil</p>
                    <p className="font-medium text-[#2C1810]">Lunes a Viernes: 9:00 AM – 6:00 PM (EST)</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-gold-soft/10 flex items-center justify-center shrink-0 text-brown-coffee mt-0.5">
                    <MapPin size={16} />
                  </div>
                  <div>
                    <p className="font-bold text-[10px] uppercase tracking-wider text-brown-coffee/80">Ubicación Princial</p>
                    <p className="font-medium text-[#2C1810]">Tampa, Florida (Consultas por videollamada a nivel nacional)</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-3 border-t border-brown-coffee/10">
                  <div className="w-8 h-8 rounded-full bg-[#C8A96B]/15 flex items-center justify-center shrink-0 mt-1">
                    <ShieldCheck size={18} className="text-[#C8A96B]" />
                  </div>
                  <div className="space-y-1">
                    <p className="font-serif font-bold text-sm text-[#2C1810]">Credenciales Certificadas</p>
                    <p className="text-xs text-[#2C1810]/75 leading-relaxed font-normal">
                      Asesora licenciada del departamento de regulación financiera para la protección familiar.
                    </p>
                    <div className="grid grid-cols-2 gap-2 pt-2 text-[10px] font-mono uppercase tracking-wider text-brown-coffee/90">
                      <div>
                        <span className="block text-dark-text/60 text-[9px] font-bold">LICENSE #</span>
                        W836254 (FL)
                      </div>
                      <div>
                        <span className="block text-dark-text/60 text-[9px] font-bold">NPN</span>
                        20194852
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
