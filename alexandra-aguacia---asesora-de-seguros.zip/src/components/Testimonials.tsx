import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export default function Testimonials() {
  const reviews = [
    {
      id: "review-maria",
      initials: "MG",
      quote: "Alexandra me explicó todo en español y sin complicaciones. Ahora tengo de verdad paz mental sabiendo que mi familia está protegida si yo no estoy.",
      author: "María G.",
      location: "Tampa, FL",
      tag: "Protección Hipotecaria"
    },
    {
      id: "review-carlos",
      initials: "CR",
      quote: "Gracias a Alexandra encontré un plan IUL que se ajusta a mi presupuesto. Lo mejor de todo es saber que mi dinero crece libre de impuestos y sin riesgo de perder.",
      author: "Carlos R.",
      location: "Orlando, FL",
      tag: "Seguro con Inversión (IUL)"
    },
    {
      id: "review-ana",
      initials: "AL",
      quote: "Nunca pensé que era tan intuitivo y rápido obtener un seguro de vida. Alexandra fue sumamente paciente, resolvió todas mis dudas y fue muy profesional.",
      author: "Ana L.",
      location: "Miami, FL",
      tag: "Seguro de Vida"
    }
  ];

  return (
    <section 
      id="testimonios" 
      className="py-24 bg-beige-warm text-[#2C1810]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee/90 mb-3 font-mono"
          >
            Casos de Éxito
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810]"
          >
            Lo que dicen mis clientes
          </motion.h2>
          <div className="w-16 h-1 bg-[#6F4E37] mx-auto mt-4 rounded-full" />
        </div>

        {/* Reviews Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, idx) => (
            <motion.div
              key={review.id}
              id={review.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: idx * 0.15 }}
              className="bg-white-cream border border-brown-coffee/15 rounded-2xl p-8 shadow-md hover:shadow-xl hover:scale-[1.01] transition-transform flex flex-col justify-between relative group"
            >
              {/* Quotation icon watermarked */}
              <Quote className="absolute right-6 top-6 text-gold-soft/10 group-hover:text-gold-soft/15 transition-colors" size={60} />

              <div>
                {/* Gold Stars */}
                <div className="flex gap-1 mb-5">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-amber-500 font-bold text-base" aria-hidden="true">★</span>
                  ))}
                </div>

                {/* Quote statement */}
                <p className="text-dark-text/90 italic font-normal text-sm sm:text-base leading-relaxed mb-6 block relative z-10">
                  "{review.quote}"
                </p>
              </div>

              {/* Author Footer */}
              <div className="border-t border-beige-warm/30 pt-4 flex items-center gap-3.5 mt-auto">
                {/* Initials avatar circle */}
                <div className="w-10 h-10 rounded-full bg-brown-coffee text-white-cream flex items-center justify-center font-bold text-sm tracking-wider uppercase border border-gold-soft/20 shadow-sm shrink-0">
                  {review.initials}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-dark-text">{review.author}</h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-[#2C1810]/70 mt-0.5">
                    <span className="font-semibold">{review.location}</span>
                    <span>•</span>
                    <span className="text-[#6F4E37] bg-gold-soft/10 px-2 py-0.5 rounded font-medium text-[10px] uppercase tracking-wide">{review.tag}</span>
                  </div>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
