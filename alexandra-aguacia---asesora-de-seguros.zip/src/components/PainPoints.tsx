import React from 'react';
import { motion } from 'motion/react';
import { Home, HeartHandshake, TrendingDown, ArrowRight } from 'lucide-react';

export default function PainPoints() {
  const painCards = [
    {
      id: "pain-card-mortgage",
      icon: <Home className="text-brown-coffee" size={28} />,
      emoji: "🏠",
      question: "¿Si fallezco, ¿quién paga mi hipoteca?",
      description: "La hipoteca es usualmente la deuda más grande de una familia. Sin tu ingreso, tus seres queridos podrían enfrentar dificultades extremas para conservar su hogar."
    },
    {
      id: "pain-card-legacy",
      icon: <HeartHandshake className="text-brown-coffee" size={28} />,
      emoji: "👨‍👩‍👧",
      question: "Quiero dejar dinero a mis hijos pero no sé cómo",
      description: "Construir un patrimonio heredable libre de impuestos federales y estatales parece complicado. Crees que necesitas ser millonario para dejar protección real."
    },
    {
      id: "pain-card-inflation",
      icon: <TrendingDown className="text-brown-coffee" size={28} />,
      emoji: "📈",
      question: "Quiero ahorrar sin perder dinero cuando el mercado baja",
      description: "Las cuentas de ahorro tradicionales no rinden suficiente y la bolsa es inestable. Buscas una alternativa que crezca de forma segura frente a pérdidas bursátiles."
    }
  ];

  const handleScrollToServices = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const servicesSection = document.querySelector('#servicios');
    if (servicesSection) {
      const offset = 80;
      const targetPosition = servicesSection.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section 
      id="problema" 
      className="py-20 bg-beige-warm text-[#2C1810]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee/80 mb-3 font-mono"
          >
            Preocupaciones Comunes
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810] tracking-tight leading-snug"
          >
            ¿Te identificas con alguna de estas situaciones?
          </motion.h2>
          <div className="w-16 h-1 bg-brown-coffee mx-auto mt-4 rounded-full" />
        </div>

        {/* Pain Cards Row/Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {painCards.map((card, idx) => (
            <motion.div
              key={card.id}
              id={card.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: idx * 0.15 }}
              className="bg-white-cream border-t-4 border-gold-soft hover:shadow-xl transition-all duration-300 rounded-2xl p-8 flex flex-col justify-between group"
            >
              <div>
                {/* Decorative Elements */}
                <div className="flex justify-between items-start mb-6">
                  <div className="p-3 bg-beige-warm/30 rounded-xl group-hover:bg-[#C8A96B]/20 transition-all">
                    {card.icon}
                  </div>
                  <span className="text-3xl leading-none" role="img" aria-label="icono descriptivo">
                    {card.emoji}
                  </span>
                </div>

                <h3 className="font-serif text-xl font-bold text-dark-text mb-4 leading-normal">
                  {card.question}
                </h3>
                
                <p className="text-sm text-dark-text/85 leading-relaxed font-normal">
                  {card.description}
                </p>
              </div>

              {/* Card micro-footer */}
              <div className="mt-8 pt-4 border-t border-beige-warm/30 text-xs text-brown-coffee/70 uppercase tracking-wider font-semibold font-mono">
                Situación real de riesgo
              </div>
            </motion.div>
          ))}
        </div>

        {/* Elegant Section Bottom Link/CTA */}
        <div className="mt-16 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4 }}
          >
            <a
              id="pain-cta-services"
              href="#servicios"
              onClick={handleScrollToServices}
              className="inline-flex items-center gap-2 bg-brown-coffee text-white-cream hover:bg-dark-text text-sm sm:text-base font-bold py-3.5 px-8 rounded-full shadow-lg hover:shadow-xl transition-all active:scale-95 group focus:outline-none focus:ring-2 focus:ring-gold-soft"
            >
              Tengo la solución para ti
              <ArrowRight size={16} className="text-gold-soft group-hover:translate-x-1.5 transition-transform" />
            </a>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
