import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export default function FAQ() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "¿Necesito ser ciudadano americano para obtener un seguro?",
      answer: "No, en lo absoluto. Existen opciones muy sólidas disponibles para residentes permanentes, personas con visa de trabajo, e incluso para personas que declaran impuestos usando un número de ITIN, dependiendo de la compañía aseguradora."
    },
    {
      question: "¿Cuánto cuesta un seguro de vida?",
      answer: "El costo varía según tu edad, estado de salud, tipo de póliza y cobertura elegida. Existen planes sumamente accesibles pensados para el presupuesto de familias trabajadoras, con cuotas que inician desde menos de $1 al día."
    },
    {
      question: "¿En cuánto tiempo se activa la póliza?",
      answer: "Muchas pólizas modernas cuentan con aprobación express sin examen médico de por medio y se activan en cuestión de 24 a 48 horas. Otros planes tradicionales con requisitos médicos pueden tomar habitualmente entre 2 y 4 semanas."
    },
    {
      question: "¿Qué pasa si dejo de pagar?",
      answer: "Si dejas de pagar, tu cobertura entra en un 'periodo de gracia' obligatorio (usualmente de 30 días) para evitar que venza. Si tu situación financiera cambia, puedes llamarme y buscaremos de inmediato ajustar o reestructurar el monto a una opción viable."
    },
    {
      question: "¿Puedo tener más de un seguro?",
      answer: "Sí, es completamente legal y en muchos casos muy sabio. Puedes tener, por ejemplo, un seguro de Protección Hipotecaria para respaldar el saldo de tu casa y paralelamente un plan IUL para construir ahorros libres de impuestos para tu jubilación."
    }
  ];

  const toggleFAQ = (index: number) => {
    if (activeIndex === index) {
      setActiveIndex(null);
    } else {
      setActiveIndex(index);
    }
  };

  return (
    <section 
      id="faq" 
      className="py-24 bg-white-cream text-dark-text"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee mb-3 font-mono"
          >
            Información Útil
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl font-extrabold text-[#2C1810]"
          >
            Preguntas Frecuentes
          </motion.h2>
          <p className="text-[#6F4E37] text-sm mt-1">
            Resuelvo tus inquietudes para que tomes una decisión informada y certera.
          </p>
          <div className="w-16 h-1 bg-gold-soft mx-auto mt-4 rounded-full" />
        </div>

        {/* Custom Pure-React Accordion Stack */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = activeIndex === idx;
            return (
              <div
                key={idx}
                className="bg-white border border-[#D8C3A5]/40 rounded-xl overflow-hidden shadow-sm hover:border-gold-soft/50 transition-all duration-200"
              >
                <button
                  id={`faq-btn-${idx}`}
                  onClick={() => toggleFAQ(idx)}
                  aria-expanded={isOpen}
                  className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 font-semibold text-sm sm:text-base text-dark-text focus:outline-none hover:text-brown-coffee transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <HelpCircle size={18} className="text-gold-soft shrink-0" />
                    <span>{faq.question}</span>
                  </div>
                  <ChevronDown
                    size={18}
                    className={`text-brown-coffee/60 shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180 text-gold-soft' : ''}`}
                  />
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`faq-content-${idx}`}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.25, ease: 'easeInOut' }}
                    >
                      <div className="px-6 pb-6 text-sm sm:text-base text-dark-text/80 leading-relaxed border-t border-beige-warm/15 pt-2 ml-7 bg-beige-warm/5 font-normal">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
