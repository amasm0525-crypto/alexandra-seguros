import React from 'react';
import { motion } from 'motion/react';
import { Home, Shield, TrendingUp, CheckCircle } from 'lucide-react';

export default function Services() {
  const services = [
    {
      id: "service-mortgage",
      icon: <Home className="text-white-cream" size={32} />,
      emoji: "🏠",
      title: "Protección Hipotecaria",
      description: "Si algo te pasa, tu familia no pierde el hogar. Este seguro cubre el pago de tu hipoteca para que tus seres queridos estén seguros.",
      keyBenefit: "Tu casa, siempre protegida.",
      accentBg: "bg-brown-coffee"
    },
    {
      id: "service-life",
      icon: <Shield className="text-white-cream" size={32} />,
      emoji: "🛡️",
      title: "Seguro de Vida",
      description: "Deja un legado económico para tu familia. Un seguro de vida garantiza que tus hijos y cónyuge tendrán estabilidad sin importar lo que pase.",
      keyBenefit: "Tranquilidad para los que amas.",
      accentBg: "bg-gold-soft"
    },
    {
      id: "service-iul",
      icon: <TrendingUp className="text-white-cream" size={32} />,
      emoji: "📈",
      title: "IUL — Seguro con Inversión",
      description: "Haz crecer tu dinero libre de impuestos con un seguro de vida indexado (Indexed Universal Life). Ganas cuando el mercado de valores sube, y cuentas con garantía del 0% contra pérdidas si el mercado baja.",
      keyBenefit: "Tu dinero trabaja para ti.",
      accentBg: "bg-dark-text"
    }
  ];

  return (
    <section 
      id="servicios" 
      className="py-24 bg-[#F8F5F0] text-dark-text"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-widest font-bold text-brown-coffee mb-3 font-mono"
          >
            Servicios Certificados
          </motion.p>
          <motion.h2 
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#2C1810]"
          >
            ¿Cómo puedo ayudarte?
          </motion.h2>
          <p className="text-[#6F4E37] text-sm sm:text-base mt-2">
            Planes diseñados a la medida de tu presupuesto y tus metas familiares.
          </p>
          <div className="w-16 h-1 bg-gold-soft mx-auto mt-4 rounded-full" />
        </div>

        {/* Stack of Horizontal Cards with Hover Effects as requested */}
        <div className="space-y-8 max-w-5xl mx-auto">
          {services.map((service, idx) => (
            <motion.div
              key={service.id}
              id={service.id}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="bg-white border border-beige-warm/30 rounded-2xl overflow-hidden hover:shadow-2xl hover:border-gold-soft/50 transition-all duration-300 group"
            >
              <div className="grid grid-cols-1 md:grid-cols-12">
                
                {/* Accent/Icon block (3 columns) */}
                <div className={`md:col-span-3 ${service.accentBg} p-8 flex flex-col justify-center items-center text-center gap-4 relative min-h-[160px] md:min-h-full`}>
                  {/* Decorative background visual indicator */}
                  <div className="absolute top-0 right-0 bottom-0 left-0 bg-black/5 mix-blend-overlay" />
                  <div className="relative z-10 w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center border border-white/20 select-none shadow">
                    {service.icon}
                  </div>
                  <span className="text-3xl relative z-10 leading-none">{service.emoji}</span>
                </div>

                {/* Content Block (9 columns split on desktop into descriptions and direct benefit) */}
                <div className="md:col-span-9 p-8 sm:p-10 flex flex-col justify-between">
                  <div>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                      <h3 className="font-serif text-2xl font-bold text-dark-text group-hover:text-brown-coffee transition-colors">
                        {service.title}
                      </h3>
                      <div className="inline-flex self-start sm:self-auto items-center gap-1.5 px-3 py-1 rounded-full bg-beige-warm/20 text-[#6F4E37] text-xs font-semibold">
                        <CheckCircle size={12} className="text-[#C8A96B]" />
                        Cobertura en EE.UU.
                      </div>
                    </div>
                    <p className="text-sm sm:text-base text-dark-text/80 leading-relaxed font-normal">
                      {service.description}
                    </p>
                  </div>

                  {/* Horizontal Key Benefit section */}
                  <div className="mt-8 pt-6 border-t border-beige-warm/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-[#C8A96B] animate-pulse" />
                      <span className="text-xs sm:text-sm font-semibold tracking-wider uppercase text-brown-coffee">
                        Beneficio clave: <strong className="text-dark-text normal-case">{service.keyBenefit}</strong>
                      </span>
                    </div>
                    <a
                      id={`${service.id}-cta`}
                      href="https://wa.me/18133047291"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-1.5 text-xs font-bold uppercase tracking-wider text-brown-coffee hover:text-gold-soft cursor-pointer after:content-['→'] after:ml-1 group-hover:after:translate-x-1.5 transition-all"
                    >
                      Consultar este plan
                    </a>
                  </div>

                </div>

              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
